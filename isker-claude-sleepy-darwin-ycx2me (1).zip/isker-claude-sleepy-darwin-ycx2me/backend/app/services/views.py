"""Builds API response objects from database state (shared by several routes)."""

from __future__ import annotations

from sqlalchemy import func, select
from sqlalchemy.orm import Session, joinedload

from app.ai.privacy import truncate
from app.ai.providers import heuristic_insight
from app.ai.service import RULE_BASED as AI_RULE_BASED
from app.core.i18n import lang as tr_lang
from app.core.i18n import tr
from app.models import (
    AIAnalysis,
    AIEvaluation,
    Answer,
    AssessmentAttempt,
    Competency,
    CompetencyArea,
    CompetencyGap,
    CompetencyScore,
    LearningResource,
    PracticalTask,
    Recommendation,
    User,
)
from app.models.enums import ActivityKind, AIInputType, AttemptStatus, ContentStatus, Difficulty
from app.schemas.assessment import AttemptSummary, CompetencyRef
from app.schemas.competency import CompetencyScoreOut
from app.schemas.results import ActivityOut, AreaScore, InsightOut, ProfileOverview, RecommendationOut
from app.services import entitlements, scoring
from app.services import gaps as gap_service
from app.services import recommendations as rec_service
from app.services.levels import DEFAULT_TARGET, gap_band, level_name_for
from app.services.profile import area_scores, comparison, completed_attempts, current_scores, history, overall_score


def type_label(value: str) -> str:
    """Localized label of a resource type (or "task" / "reflection")."""
    return tr(f"type.{value}")


def competencies(db: Session, published_only: bool = False) -> list[Competency]:
    """All competencies (for lookups by id), or only the published ones the learner platform offers."""
    stmt = select(Competency).options(joinedload(Competency.area)).order_by(Competency.sort_order)
    if published_only:
        stmt = stmt.where(Competency.status == ContentStatus.PUBLISHED)
    return list(db.scalars(stmt))


def attempt_summary(db: Session, att: AssessmentAttempt, total: int | None = None) -> AttemptSummary:
    from app.services.assessments import is_answered, questions_for

    qs = questions_for(db, att)
    answers = {a.question_id: a for a in att.answers}
    comp = att.scope_competency
    return AttemptSummary(
        id=att.id,
        scope=att.scope,
        status=att.status,
        current_index=att.current_index,
        competency=CompetencyRef(id=comp.id, code=comp.code, name=comp.name) if comp else None,
        answered=sum(1 for q in qs if is_answered(q, answers.get(q.id))),
        total=total if total is not None else len(qs),
        sequence=att.sequence,
        overall_score=att.overall_score,
        started_at=att.started_at,
        completed_at=att.completed_at,
    )


RULE_BASED = AI_RULE_BASED


def _rerendered(db: Session, o: dict) -> dict:
    """Rule-based insights are rebuilt from their stored ids and numbers so they follow the interface language."""
    refs = o.get("refs") or {}
    best = db.get(Competency, refs["strongest"]) if refs.get("strongest") else None
    if best is None:
        return o
    gap_c = db.get(Competency, refs["top_gap"]) if refs.get("top_gap") else None
    res = db.get(LearningResource, refs["top_resource"]) if refs.get("top_resource") else None
    facts = {
        "strongest": {"name": best.name, "score": refs.get("strongest_score")},
        "top_gap": (
            {"name": gap_c.name, "score": refs.get("gap_score"), "target": refs.get("gap_target")} if gap_c else None
        ),
        "top_resource": res.title if res else None,
    }
    return {**o, **heuristic_insight(facts)}


def insight_out(ev: AIEvaluation | None, db: Session | None = None) -> InsightOut | None:
    if ev is None or not ev.output:
        return None
    o = ev.output
    language = ev.language
    if db is not None and ev.provider in RULE_BASED and o.get("refs"):
        o = _rerendered(db, o)
        language = tr_lang()
    return InsightOut(
        headline=o.get("headline", ""),
        body=o.get("body", ""),
        next_step=o.get("next_step", ""),
        confidence=ev.confidence,
        provider=ev.provider,
        evaluation_id=ev.id,
        generated_at=ev.created_at,
        language=language,
    )


def latest_insight(db: Session, user_id: int, attempt_id: int | None = None) -> AIEvaluation | None:
    q = select(AIEvaluation).where(
        AIEvaluation.user_id == user_id, AIEvaluation.input_type == AIInputType.PROFILE_INSIGHT
    )
    if attempt_id is not None:
        q = q.where(AIEvaluation.attempt_id == attempt_id)
    return db.scalar(q.order_by(AIEvaluation.id.desc()))


def score_out(
    c: Competency, s: CompetencyScore | None, g: CompetencyGap | None, change: int | None = None
) -> CompetencyScoreOut:
    target = g.target_score if g else c.default_target or DEFAULT_TARGET
    gap = (g.gap if g else max(0, target - s.score)) if s else None
    return CompetencyScoreOut(
        competency_id=c.id,
        code=c.code,
        name=c.name,
        short_name=c.short_name,
        area_code=c.area.code,
        area_name=c.area.name,
        description=c.description,
        score=s.score if s else None,
        level=level_name_for(s.score) if s else None,
        target=target,
        gap=gap,
        gap_band=gap_band(gap) if gap is not None else None,
        priority_label=tr(f"priority.{g.priority_label}") if g else None,
        priority_rank=g.priority_rank if g else None,
        confidence=s.confidence if s else None,
        explanation=scoring.explain_stored(s) if s else None,
        evidence_level=s.evidence_level if s else None,
        evidence_count=len(s.evidence) if s and s.evidence is not None else None,
        assessed_at=s.created_at if s else None,
        change=change,
    )


def profile_overview(db: Session, user_id: int, as_of_attempt: AssessmentAttempt | None = None) -> ProfileOverview:
    attempts = completed_attempts(db, user_id)
    areas = list(db.scalars(select(CompetencyArea).order_by(CompetencyArea.sort_order)))
    comps = competencies(db, published_only=True)
    if not attempts:
        return ProfileOverview(
            has_profile=False,
            overall=None,
            level=None,
            previous_overall=None,
            change=None,
            assessed_at=None,
            attempt_id=None,
            areas=[AreaScore(code=a.code, name=a.name, color_token=a.color_token, score=None) for a in areas],
            competencies=[score_out(c, None, None) for c in comps],
            strengths=[],
            priority_gaps=[],
            insight=None,
        )
    current_att = as_of_attempt or attempts[-1]
    idx = next(i for i, a in enumerate(attempts) if a.id == current_att.id)
    prev_att = attempts[idx - 1] if idx > 0 else None
    scores = current_scores(db, user_id, up_to_attempt_id=current_att.id)
    prev_scores = current_scores(db, user_id, up_to_attempt_id=prev_att.id) if prev_att else {}
    gaps = {
        g.competency_id: g for g in db.scalars(select(CompetencyGap).where(CompetencyGap.attempt_id == current_att.id))
    }
    if not gaps and as_of_attempt is None:
        gaps = {g.competency_id: g for g in gap_service.latest_gaps(db, user_id)}
    # Unpublished competencies appear only where the learner has a measurement (history is never hidden).
    comps = [c for c in competencies(db) if c.status == ContentStatus.PUBLISHED or c.id in scores]
    a_scores = area_scores(db, scores)
    overall = current_att.overall_score if current_att.overall_score is not None else overall_score(scores)
    cmp = comparison(prev_att, current_att)
    # A different scoring method makes the difference meaningless: no change numbers then.
    prev_overall = prev_att.overall_score if prev_att and cmp != "method_changed" else None
    items = []
    for c in comps:
        s = scores.get(c.id)
        p = prev_scores.get(c.id) if cmp != "method_changed" else None
        items.append(score_out(c, s, gaps.get(c.id), (s.score - p.score) if s and p else None))
    measured = [i for i in items if i.score is not None]
    strengths = sorted(measured, key=lambda i: (-(i.score or 0), i.competency_id))[:3]
    pgaps = sorted([i for i in measured if (i.gap or 0) >= 10], key=lambda i: (i.priority_rank or 99, -(i.gap or 0)))[
        :3
    ]
    return ProfileOverview(
        has_profile=True,
        overall=overall,
        level=level_name_for(overall) if overall is not None else None,
        previous_overall=prev_overall,
        change=(overall - prev_overall) if prev_overall is not None and overall is not None else None,
        comparison=cmp,
        assessed_at=current_att.completed_at,
        attempt_id=current_att.id,
        areas=[
            AreaScore(code=a.code, name=a.name, color_token=a.color_token, score=a_scores.get(a.code)) for a in areas
        ],
        competencies=items,
        strengths=strengths,
        priority_gaps=pgaps,
        insight=insight_out(
            latest_insight(db, user_id, current_att.id)
            or (latest_insight(db, user_id) if as_of_attempt is None else None),
            db,
        ),
    )


def recommendation_out(db: Session, rec: Recommendation) -> RecommendationOut:
    comp = db.get(Competency, rec.competency_id)
    gap = db.get(CompetencyGap, rec.gap_id)
    assert comp is not None and gap is not None
    res = db.get(LearningResource, rec.resource_id) if rec.resource_id else None
    task = db.get(PracticalTask, rec.task_id) if rec.task_id else None
    unlocked = rec_service.reassess_unlocked(rec)
    acts = []
    for a in rec.activities:
        dur, typ = None, None
        if a.kind == ActivityKind.LEARN and res:
            dur, typ = res.duration_minutes, type_label(res.type.value)
        elif a.kind == ActivityKind.PRACTICE and task:
            dur, typ = task.duration_minutes, type_label("task")
        # Titles and prompts are rendered now (not the stored copies) so they follow the interface language.
        if a.kind == ActivityKind.LEARN and res:
            title = res.title
        elif a.kind == ActivityKind.PRACTICE and task:
            title = task.title
        elif a.kind == ActivityKind.REFLECT:
            title = tr("step.reflect")
        elif a.kind == ActivityKind.REASSESS:
            title = tr("step.reassess", name=comp.name)
        else:
            title = a.title
        prompt = (
            (comp.reflection_prompt or tr("step.reflect_prompt", name=comp.name))
            if a.kind == ActivityKind.REFLECT
            else a.prompt
        )
        acts.append(
            ActivityOut(
                id=a.id,
                kind=a.kind,
                title=title,
                status=a.status,
                locked=a.kind == ActivityKind.REASSESS and not unlocked and a.status.value != "done",
                resource_id=a.resource_id,
                task_id=a.task_id,
                prompt=prompt,
                response_text=a.response_text,
                duration_minutes=dur,
                type=typ,
                completed_at=a.completed_at,
            )
        )
    done = sum(1 for a in rec.activities if a.status.value == "done")
    return RecommendationOut(
        id=rec.id,
        priority=rec.priority,
        priority_score=rec.priority_score,
        status=rec.status,
        competency_id=comp.id,
        competency_code=comp.code,
        competency_name=comp.name,
        current=gap.current_score,
        target=gap.target_score,
        gap=gap.gap,
        band=gap.band,
        reason=rec_service.localized_reason(rec),
        goal=rec.goal.title if rec.goal else None,
        resource=(
            {
                "id": res.id,
                "title": res.title,
                "description": res.description,
                "type": type_label(res.type.value),
                "duration_minutes": res.duration_minutes,
                "difficulty": res.difficulty.value,
            }
            if res
            else None
        ),
        task=(
            {
                "id": task.id,
                "title": task.title,
                "duration_minutes": task.duration_minutes,
                "difficulty": task.difficulty.value,
            }
            if task
            else None
        ),
        activities=acts,
        progress_pct=round(done / len(rec.activities) * 100) if rec.activities else 0,
        created_at=rec.created_at,
    )


def attempt_count(db: Session, user_id: int) -> int:
    return (
        db.scalar(
            select(func.count(AssessmentAttempt.id)).where(
                AssessmentAttempt.user_id == user_id, AssessmentAttempt.status == AttemptStatus.COMPLETED
            )
        )
        or 0
    )


__all__ = [
    "attempt_summary",
    "competencies",
    "history",
    "insight_out",
    "latest_insight",
    "profile_overview",
    "recommendation_out",
    "score_out",
]


def analysis_view(db: Session, att: AssessmentAttempt, row: AIAnalysis | None) -> dict:
    """The AI analysis of `att` for the screen. The model's texts are shown as written (in `language`); competency
    names, scores, resource and task titles come from the database in the reader's language, and an item that is no
    longer published or available is marked instead of linked. Scores are this attempt's stored scores."""
    if row is None:
        return {"status": "none", "attempt_id": att.id}
    base = {
        "status": row.status, "attempt_id": att.id, "language": row.language, "error_code": row.error_code,
        "provider": row.provider, "model": row.model, "rule_based": row.provider in AI_RULE_BASED,
        "runs": row.runs, "completed_at": row.completed_at, "analysis": None,
    }
    if row.status != "completed" or not row.output:
        return base
    out = row.output
    if row.provider in AI_RULE_BASED and row.language != tr_lang():
        # Rule-based texts come from the catalog: written again in the reader's language (no AI call, same rules).
        from app.ai.analysis import build_facts, heuristic_analysis

        owner = db.get(User, att.user_id)
        if owner is not None:
            out = heuristic_analysis(build_facts(db, owner, att))
            base["language"] = tr_lang()
    comps = {c.code: c for c in db.scalars(select(Competency))}
    rows = db.scalars(select(CompetencyScore).where(CompetencyScore.attempt_id == att.id))
    scores = {s.competency_id: s for s in rows}
    user = db.get(User, att.user_id)
    advanced_ok = user is not None and entitlements.allows(db, user, "learning.advanced_resources")

    def comp(code: str) -> dict:
        c = comps.get(code)
        s = scores.get(c.id) if c else None
        return {"code": code, "name": c.name if c else code, "score": s.score if s else None,
                "evidence_level": s.evidence_level if s else None}

    def resource(rid: int | None) -> dict | None:
        r = db.get(LearningResource, rid) if rid else None
        if r is None:
            return None
        allowed = advanced_ok or r.difficulty != Difficulty.ADVANCED
        return {"id": r.id, "title": r.title, "type": r.type.value, "minutes": r.duration_minutes,
                "available": r.status == ContentStatus.PUBLISHED and allowed}

    def task(tid: int | None) -> dict | None:
        t = db.get(PracticalTask, tid) if tid else None
        if t is None:
            return None
        return {"id": t.id, "title": t.title, "minutes": t.duration_minutes,
                "available": t.status == ContentStatus.PUBLISHED}

    answer_ids = {i for group in ("strengths", "development_areas", "competency_insights")
                  for c in out.get(group, []) for i in c.get("evidence", [])}
    answers = {a.id: a for a in db.scalars(select(Answer).where(Answer.attempt_id == att.id,
                                                                 Answer.id.in_(answer_ids)))} if answer_ids else {}

    def evidence(ids: list[int]) -> list[dict]:
        # The learner's own answers (this attempt only), in the reader's language; free text shortened, not redacted.
        out_ = []
        for i in ids:
            a = answers.get(i)
            if a is not None:
                text = a.option.label if a.option is not None else truncate(a.text_response or "", 240)
                out_.append({"answer_id": a.id, "question": truncate(a.question.text, 200), "response": text})
        return out_

    def claim(c: dict) -> dict:
        # Outputs written before claims carried evidence have none: shown without it, confidence unknown.
        return {**comp(c["competency_code"]), "evidence": evidence(c.get("evidence", [])),
                "reasoning_summary": c.get("reasoning_summary"), "confidence": c.get("confidence")}

    analysis = {
        "summary": out["summary"],
        "strengths": [{**claim(s), "explanation": s["explanation"]} for s in out.get("strengths", [])],
        "development_areas": [{**claim(d), "explanation": d["explanation"], "priority": d["priority"]}
                              for d in sorted(out.get("development_areas", []), key=lambda d: d["priority"])],
        "competency_insights": [{**claim(i), "insight": i["insight"]} for i in out.get("competency_insights", [])],
        "recommended_actions": [{"competency": comp(a["competency_code"]), "kind": a["kind"], "reason": a["reason"],
                                 "resource": resource(a.get("resource_id")), "task": task(a.get("task_id"))}
                                for a in out.get("recommended_actions", [])],
        "milestones": [{**comp(m["competency_code"]), "objective": m["objective"], "measure": m["measure"],
                        "target_weeks": m["target_weeks"]} for m in out.get("milestones", [])],
        "progress_notes": [{**comp(n["competency_code"]), "explanation": n["explanation"]}
                           for n in out.get("progress_notes", [])],
        "limitations": out.get("limitations") or out.get("confidence_notes", []),
        "additional_questions": out.get("additional_questions", []),
        "reassessment_weeks": out.get("reassessment_weeks"),
    }
    return {**base, "analysis": analysis}
